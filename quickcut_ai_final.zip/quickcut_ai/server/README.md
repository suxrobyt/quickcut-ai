# QuickCut AI Server

Server-side AI director + media upload + FFmpeg MVP renderer.

## Local
1. Install Node.js 22 and FFmpeg.
2. `npm install`
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY`.
4. `npm start`

## Docker
`docker build -t quickcut-ai-server .`
`docker run --rm -p 8787:8787 --env-file .env quickcut-ai-server`

Never put OPENAI_API_KEY in the Android app. Keep it on the server.
