import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import crypto from 'crypto';

dotenv.config();
const app = express();
const port = Number(process.env.PORT || 8787);
const root = path.resolve('.');
const uploadDir = path.join(root, 'uploads');
const outputDir = path.join(root, 'outputs');
const tmpDir = path.join(root, 'tmp');
for (const d of [uploadDir, outputDir, tmpDir]) fs.mkdirSync(d, { recursive: true });
app.use(cors());
app.use(express.json({ limit: '8mb' }));
app.use('/outputs', express.static(outputDir));
const upload = multer({ dest: uploadDir, limits: { fileSize: 1024 * 1024 * 1024, files: 20 } });
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.get('/health', (_, res) => res.json({ ok: true, service: 'QuickCut AI', aiConfigured: !!openai, ffmpeg: true }));

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args);
    let stderr = '';
    p.stderr.on('data', d => stderr += d.toString());
    p.on('close', code => code === 0 ? resolve() : reject(new Error(stderr.slice(-5000))));
    p.on('error', reject);
  });
}
async function duration(file) {
  return new Promise((resolve, reject) => {
    const p = spawn('ffprobe', ['-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',file]);
    let out=''; p.stdout.on('data',d=>out+=d); p.on('close',c=>c===0?resolve(Number(out)||0):reject(new Error('ffprobe failed')));
  });
}
async function frameData(file, seconds, name) {
  const out = path.join(tmpDir, `${name}.jpg`);
  await run('ffmpeg', ['-y','-ss',String(Math.max(0,seconds)),'-i',file,'-frames:v','1','-vf','scale=640:-2',out]);
  return `data:image/jpeg;base64,${fs.readFileSync(out).toString('base64')}`;
}
function mediaSummary(files) {
  return files.map((f,i)=>({ index:i, name:f.originalname, mime:f.mimetype, size:f.size }));
}

app.post('/ai/montage', upload.array('media', 20), async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error:'AI server is not configured. Set OPENAI_API_KEY.' });
    const files = req.files || [];
    const videos = files.filter(f => f.mimetype.startsWith('video/'));
    const photos = files.filter(f => f.mimetype.startsWith('image/'));
    const music = files.find(f => f.mimetype.startsWith('audio/'));
    const style = req.body.style || 'Shorts';
    const ratio = req.body.ratio || '9:16';
    const instruction = req.body.instruction || 'Eng qiziqarli joylarni tanlab dinamik qisqa video yarat.';
    const targetDuration = Number(req.body.duration || 30);
    const frames=[];
    for (let i=0;i<videos.length;i++) {
      const d=await duration(videos[i].path);
      const points=[Math.min(d*.15, Math.max(0,d-0.1)), Math.min(d*.5, Math.max(0,d-0.1)), Math.min(d*.85, Math.max(0,d-0.1))];
      for(let j=0;j<points.length;j++) frames.push({videoIndex:i, point:points[j], image:await frameData(videos[i].path,points[j],`${path.basename(videos[i].path)}_${j}`), duration:d});
    }
    const content=[{type:'input_text',text:`You are QuickCut AI's professional video editing director. Understand Uzbek. Analyze the provided video frames and create a practical montage plan. User instruction: ${instruction}\nStyle: ${style}\nAspect ratio: ${ratio}\nTarget duration: ${targetDuration}s\nVideo metadata: ${JSON.stringify(mediaSummary(videos))}\nPhotos: ${photos.length}\nMusic supplied: ${!!music}\nReturn ONLY JSON with: summary, targetDuration, cuts (array of {sourceIndex,start,end}), photos (array of {sourceIndex,at}), transitions (array), effects (array), audio (array), subtitles (array). Use sourceIndex relative to the VIDEO list. Do not invent precise scene contents beyond the supplied frames; use conservative cuts when uncertain.`}];
    for (const f of frames) content.push({type:'input_image',image_url:f.image});
    const response=await openai.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:[{role:'user',content}],text:{format:{type:'json_object'}}});
    let plan; try { plan=JSON.parse(response.output_text); } catch { return res.status(502).json({error:'AI returned invalid JSON',raw:response.output_text}); }
    res.json({plan, uploaded:files.map(f=>({path:f.path,name:f.originalname,mime:f.mimetype,size:f.size})), media:{videos:videos.length,photos:photos.length,music:!!music}});
  } catch(e) { res.status(500).json({error:e?.message||'AI montage failed'}); }
});

app.post('/render-plan', async (req,res)=>{
  try {
    const { plan, videos=[], photos=[], musicPath=null, ratio='9:16', outputName=`quickcut-${Date.now()}.mp4` }=req.body||{};
    if(!plan || !Array.isArray(plan.cuts) || !videos.length) return res.status(400).json({error:'Plan and videos are required.'});
    const job=crypto.randomUUID(); const parts=[];
    const size=ratio==='9:16'?'1080:1920':ratio==='1:1'?'1080:1080':ratio==='4:5'?'1080:1350':'1920:1080';
    const vf=`scale=${size}:force_original_aspect_ratio=decrease,pad=${size}:(ow-iw)/2:(oh-ih)/2`;
    for(let i=0;i<plan.cuts.length;i++){
      const c=plan.cuts[i]; const src=videos[c.sourceIndex]; if(!src) continue;
      const out=path.join(tmpDir,`${job}_${i}.mp4`); const start=Math.max(0,Number(c.start)||0); const end=Math.max(start+0.05,Number(c.end)||start+2);
      await run('ffmpeg',['-y','-ss',String(start),'-to',String(end),'-i',src,'-vf',vf,'-an','-c:v','libx264','-preset','veryfast','-crf','23','-pix_fmt','yuv420p','-r','30',out]);
      parts.push(out);
    }
    if(!parts.length) return res.status(400).json({error:'No valid cuts in AI plan.'});
    const list=path.join(tmpDir,`${job}.txt`); fs.writeFileSync(list,parts.map(p=>`file '${p.replaceAll("'","'\\''")}'`).join('\n'));
    const safe=path.basename(outputName).replace(/[^a-zA-Z0-9._-]/g,'_'); const out=path.join(outputDir,safe);
    const args=['-y','-f','concat','-safe','0','-i',list];
    if(musicPath){args.push('-i',musicPath,'-map','0:v:0','-map','1:a:0','-shortest','-c:v','libx264','-c:a','aac','-movflags','+faststart');}
    else args.push('-c:v','libx264','-c:a','aac','-movflags','+faststart');
    args.push(out); await run('ffmpeg',args);
    const base=process.env.PUBLIC_BASE_URL||`http://localhost:${port}`;
    res.json({ok:true,url:`${base}/outputs/${safe}`,file:safe});
  }catch(e){res.status(500).json({error:e?.message||'Render failed'});}
});

app.listen(port,()=>console.log(`QuickCut AI API running on ${port}`));
