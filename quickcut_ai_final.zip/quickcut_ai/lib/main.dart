import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const QuickCutApp());

class QuickCutApp extends StatefulWidget { const QuickCutApp({super.key}); @override State<QuickCutApp> createState()=>_QuickCutAppState(); }
class _QuickCutAppState extends State<QuickCutApp> {
  ThemeMode mode=ThemeMode.dark;
  @override Widget build(BuildContext context)=>MaterialApp(title:'QuickCut AI',debugShowCheckedModeBanner:false,themeMode:mode,
    theme: ThemeData(colorSchemeSeed:Colors.deepPurple,brightness:Brightness.light,useMaterial3:true),
    darkTheme: ThemeData(colorSchemeSeed:Colors.deepPurple,brightness:Brightness.dark,useMaterial3:true),
    home: HomeScreen(onTheme:(m)=>setState(()=>mode=m)));
}

class Project { String id,name,date,status; int videos,photos; Project({required this.id,required this.name,required this.date,required this.status,required this.videos,required this.photos}); Map<String,dynamic> toJson()=>{'id':id,'name':name,'date':date,'status':status,'videos':videos,'photos':photos}; static Project fromJson(Map<String,dynamic> x)=>Project(id:x['id'],name:x['name'],date:x['date'],status:x['status'],videos:x['videos'],photos:x['photos']); }

class ProjectStore {
 static Future<List<Project>> load() async { final p=await SharedPreferences.getInstance(); final s=p.getString('projects'); if(s==null)return []; return (jsonDecode(s) as List).map((e)=>Project.fromJson(e)).toList(); }
 static Future<void> save(Project x) async { final p=await SharedPreferences.getInstance(); final all=await load(); all.insert(0,x); await p.setString('projects',jsonEncode(all.map((e)=>e.toJson()).toList())); }
}

class HomeScreen extends StatelessWidget { final ValueChanged<ThemeMode> onTheme; const HomeScreen({super.key,required this.onTheme});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('QuickCut AI',style:TextStyle(fontWeight:FontWeight.bold)),actions:[IconButton(onPressed:()=>showDialog(context:c,builder:(_)=>ThemeDialog(onTheme)),icon:const Icon(Icons.brightness_6))]),body:ListView(padding:const EdgeInsets.all(20),children:[
  Container(padding:const EdgeInsets.all(24),decoration:BoxDecoration(borderRadius:BorderRadius.circular(28),gradient:LinearGradient(colors:[Colors.deepPurple,Colors.indigo])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.auto_awesome,size:42,color:Colors.white),const SizedBox(height:14),Text('Upload. AI Edits. You Create.',style:GoogleFonts.poppins(fontSize:25,fontWeight:FontWeight.w700,color:Colors.white)),const SizedBox(height:8),const Text('Videolaringizni yuklang, o‘zbekcha qilib qanday montaj xohlashingizni yozing — QuickCut AI qolganini bajaradi.',style:TextStyle(color:Colors.white70,fontSize:15)),const SizedBox(height:20),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:Colors.white,foregroundColor:Colors.deepPurple),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const CreateScreen())),icon:const Icon(Icons.movie_creation_outlined),label:const Padding(padding:EdgeInsets.all(12),child:Text('CREATE AI VIDEO')))])),
  const SizedBox(height:20),GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.55,children:[_Tile('Quick Montage',Icons.flash_on),_Tile('Music Sync',Icons.music_note),_Tile('Meme Video',Icons.sentiment_very_satisfied),_Tile('Gaming',Icons.sports_esports),_Tile('Templates',Icons.grid_view),_Tile('My Projects',Icons.folder_open)]),
  const SizedBox(height:22),const Text('AI Director',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:8),Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[const Icon(Icons.chat_bubble_outline),const SizedBox(width:12),const Expanded(child:Text('“Gaming videolarimdan 30 soniyalik tezkor Shorts qil, kill joylarini tanla va beatga mos kes.”',style:TextStyle(fontStyle:FontStyle.italic)))]))),
  const SizedBox(height:10),ListTile(leading:const Icon(Icons.settings),title:const Text('Settings'),onTap:()=>showDialog(context:c,builder:(_)=>ThemeDialog(onTheme)))
 ]); }
}
class _Tile extends StatelessWidget { final String t; final IconData i; const _Tile(this.t,this.i); @override Widget build(BuildContext c)=>Card(child:InkWell(borderRadius:BorderRadius.circular(18),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const CreateScreen())),child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Icon(i,size:30),const SizedBox(height:8),Text(t,style:const TextStyle(fontWeight:FontWeight.w600))])))); }

class ThemeDialog extends StatelessWidget { final ValueChanged<ThemeMode> onTheme; const ThemeDialog(this.onTheme,{super.key}); @override Widget build(BuildContext c)=>AlertDialog(title:const Text('Theme'),content:Column(mainAxisSize:MainAxisSize.min,children:[for(final x in [ThemeMode.dark,ThemeMode.light,ThemeMode.system])ListTile(title:Text(x.name),onTap:(){onTheme(x);Navigator.pop(c);})])); }

class CreateScreen extends StatefulWidget { const CreateScreen({super.key}); @override State<CreateScreen> createState()=>_CreateScreenState(); }
class _CreateScreenState extends State<CreateScreen> {
 List<PlatformFile> videos=[],photos=[]; PlatformFile? music; String style='Shorts',ratio='9:16'; final prompt=TextEditingController(); bool working=false; String status=''; double progress=0; VideoPlayerController? player;
 Future<void> pick(String type) async { final r=await FilePicker.platform.pickFiles(allowMultiple:type!='music',type:FileType.custom,allowedExtensions:type=='music'?['mp3','wav','m4a','aac']:type=='photos'?['jpg','jpeg','png','webp']:['mp4','mov','mkv','webm']); if(r==null)return; setState((){if(type=='videos')videos=r.files;else if(type=='photos')photos=r.files;else music=r.files.first;}); if(type=='videos'&&videos.isNotEmpty&&videos.first.path!=null){player?.dispose();player=VideoPlayerController.file(File(videos.first.path!));await player!.initialize();setState((){});}}
 Future<void> montage() async {
  if(videos.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Avval kamida bitta video tanlang.')));return;}
  setState(()=>{working=true,status='Videolar serverga yuborilmoqda...',progress=.08});
  try {
    final uri=Uri.parse('${AiService.endpoint}/ai/montage');
    final req=http.MultipartRequest('POST',uri);
    req.fields.addAll({'instruction':prompt.text,'style':style,'ratio':ratio,'duration':'30'});
    for(final f in [...videos,...photos]) { if(f.path!=null) req.files.add(await http.MultipartFile.fromPath('media',f.path!,filename:f.name)); }
    if(music?.path!=null) req.files.add(await http.MultipartFile.fromPath('media',music!.path!,filename:music!.name));
    setState(()=>{status='AI videolarni tahlil qilmoqda...',progress=.25});
    final streamed=await req.send(); final body=await streamed.stream.bytesToString();
    if(streamed.statusCode>=300) throw Exception(body);
    final data=jsonDecode(body) as Map<String,dynamic>;
    final plan=data['plan'];
    final p=Project(id:const Uuid().v4(),name:'AI Montage ${DateTime.now().hour}:${DateTime.now().minute}',date:DateTime.now().toString().substring(0,16),status:'Preview Ready',videos:videos.length,photos:photos.length);
    await ProjectStore.save(p);
    if(!mounted)return;
    setState(()=>{status='AI montage rejasi tayyor',progress=.75,working=false});
    showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('AI Montage rejasi tayyor'),content:SingleChildScrollView(child:Text(JsonEncoder.withIndent('  ').convert(plan))),actions:[TextButton(onPressed:(){Navigator.pop(context);setState(()=>working=false);},child:const Text('Regenerate')),FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('Use This Edit'))]));
  } catch(e) { if(mounted){setState(()=>{working=false;status='Xatolik: $e';progress=0});ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('AI server bilan ulanishda xatolik: $e')));}}
 }

 @override void dispose(){prompt.dispose();player?.dispose();super.dispose();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Create AI Video')),body:ListView(padding:const EdgeInsets.all(18),children:[
  _section('Media',Icons.perm_media,[_MediaButton('Add Videos',Icons.video_library,()=>pick('videos'),'${videos.length} ta'),_MediaButton('Add Photos',Icons.photo_library,()=>pick('photos'),'${photos.length} ta'),_MediaButton('Add Music',Icons.music_note,()=>pick('music'),music==null?'Tanlanmagan':music!.name)]),
  if(player!=null&&player!.value.isInitialized)Card(child:AspectRatio(aspectRatio:player!.value.aspectRatio,child:Stack(alignment:Alignment.center,children:[VideoPlayer(player!),IconButton(style:IconButton.styleFrom(backgroundColor:Colors.black54,foregroundColor:Colors.white),onPressed:(){setState(()=>player!.value.isPlaying?player!.pause():player!.play());},icon:Icon(player!.value.isPlaying?Icons.pause:Icons.play_arrow))]))),
  const SizedBox(height:16),Text('AI Director — o‘zbekcha topshiriq',style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),TextField(controller:prompt,maxLines:5,decoration:InputDecoration(hintText:'Masalan: “Videolardan 30 soniyalik gaming Shorts qil. Eng zo‘r kill joylarini tanla, beatga mos kes, zoom va slow motion qo‘sh.”',border:OutlineInputBorder(borderRadius:BorderRadius.circular(18)),prefixIcon:const Icon(Icons.auto_awesome))),
  const SizedBox(height:12),Wrap(spacing:8,runSpacing:8,children:[for(final s in ['Cinematic','Fast','Gaming','Funny','Meme','Beat Sync','Smooth','Shorts','Dramatic','Minimal'])ChoiceChip(label:Text(s),selected:style==s,onSelected:(_)=>setState(()=>style=s))]),
  const SizedBox(height:14),Row(children:[Expanded(child:DropdownButtonFormField<String>(value:ratio,decoration:const InputDecoration(labelText:'Aspect Ratio',border:OutlineInputBorder()),items:['9:16','16:9','1:1','4:5'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>ratio=x!))),const SizedBox(width:12),Expanded(child:InputDecorator(decoration:const InputDecoration(labelText:'Default',border:OutlineInputBorder()),child:Text(ratio=='9:16'?'1080×1920':'Auto')))]),
  const SizedBox(height:18),if(working)...[Text(status),const SizedBox(height:8),LinearProgressIndicator(value:progress),const SizedBox(height:18)],FilledButton.icon(onPressed:working?null:montage,icon:const Icon(Icons.auto_awesome),label:const Padding(padding:EdgeInsets.all(14),child:Text('AI MONTAGE'))),
  const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>showDialog(context:c,builder:(_)=>const ProjectDialog()),icon:const Icon(Icons.folder_open),label:const Text('My Projects'))
 ]); }
 Widget _section(String t,IconData icon,List<Widget> children)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Icon(icon),const SizedBox(width:8),Text(t,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))]),const SizedBox(height:12),...children])));
}
class _MediaButton extends StatelessWidget {final String t,sub;final IconData i;final VoidCallback on;const _MediaButton(this.t,this.i,this.on,this.sub);@override Widget build(BuildContext c)=>ListTile(onTap:on,leading:CircleAvatar(child:Icon(i)),title:Text(t),subtitle:Text(sub),trailing:const Icon(Icons.add));}

class ProjectDialog extends StatefulWidget{const ProjectDialog({super.key});@override State<ProjectDialog> createState()=>_ProjectDialogState();}
class _ProjectDialogState extends State<ProjectDialog>{List<Project> p=[];@override void initState(){super.initState();ProjectStore.load().then((x){if(mounted)setState(()=>p=x);});}@override Widget build(BuildContext c)=>AlertDialog(title:const Text('My Projects'),content:SizedBox(width:500,height:350,child:p.isEmpty?const Center(child:Text('Hozircha loyiha yo‘q.')):ListView(children:[for(final x in p)ListTile(leading:const Icon(Icons.movie),title:Text(x.name),subtitle:Text('${x.date} • ${x.videos} video • ${x.photos} rasm'),trailing:Text(x.status))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Close'))]);}

class AiService { static const endpoint=String.fromEnvironment('AI_BACKEND',defaultValue:'http://10.0.2.2:8787'); static Future<String> plan(String instruction,String style,String ratio,int videos,int photos,bool hasMusic) async { if(endpoint.isNotEmpty){try{final r=await http.post(Uri.parse('$endpoint/ai/plan'),headers:{'Content-Type':'application/json'},body:jsonEncode({'instruction':instruction,'style':style,'ratio':ratio,'videos':videos,'photos':photos,'hasMusic':hasMusic}));if(r.statusCode<300)return jsonDecode(r.body)['plan'];}catch(_){}} return 'AI reja: $ratio formatda $style uslubidagi montage. $videos ta video va $photos ta rasm tahlil qilinadi. ${hasMusic?'Musiqa beatlari bo‘yicha cut va transitionlar qo‘llanadi.':'Musiqa berilmagani uchun video ritmiga asoslanadi.'} Foydalanuvchi ko‘rsatmasi: ${instruction.trim().isEmpty?'Eng qiziqarli joylarni tanlab, dinamik qisqa video yarat.':instruction}'; } }
