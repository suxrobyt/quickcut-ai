# QuickCut AI 1.0.0

Flutter Android client + Node.js AI/video server.

## What is connected
- Uzbek natural-language AI Director
- OpenAI Responses API on the server
- Video frame extraction with FFmpeg for AI visual analysis
- Multipart media upload
- AI montage JSON plan
- Server-side FFmpeg rendering endpoint
- Local project history
- Video preview UI

## Run server
`cd server`
`npm install`
`cp .env.example .env`
Set `OPENAI_API_KEY` in `.env`.
`npm start`

For Android emulator, the default backend is `http://10.0.2.2:8787`.
For a real phone, build with your server URL:
`flutter run --dart-define=AI_BACKEND=https://YOUR-SERVER-DOMAIN`

## Build APK
`flutter pub get`
`flutter build apk --release --dart-define=AI_BACKEND=https://YOUR-SERVER-DOMAIN`

IMPORTANT: never put OPENAI_API_KEY in Flutter/Dart or inside the APK. OpenAI recommends keeping the API key in a secure server-side environment. See the official OpenAI quickstart. 
